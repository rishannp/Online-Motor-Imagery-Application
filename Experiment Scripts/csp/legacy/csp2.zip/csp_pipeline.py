# csp_pipeline.py
import numpy as np
from collections import deque

from config import (
    SAMPLING_RATE,
    CSP_BASELINE_SECONDS,
    CSP_SMOOTH_VOTES,
)
from preprocess import preprocess_window


def _logvar_feats(window_tc: np.ndarray, W: np.ndarray, picks: np.ndarray) -> np.ndarray:
    """
    window_tc: [T, C]
    W: [C, C]
    picks: [k]
    returns: [1, k] log-variance features
    """
    X = window_tc.T.astype(np.float32)  # [C, T]
    Z = (W.T @ X)                       # [C, T]
    Zp = Z[picks, :]                    # [k, T]

    var = np.var(Zp, axis=1).astype(np.float32)
    var /= (np.sum(var) + 1e-12)
    return np.log(var + 1e-12)[None, :]


class CSPPipeline:
    """
    Loads a trained CSP pack (W, picks, clf). Online:
      - blocks outputs during baseline (time-accurate)
      - uses SVM margin (decision_function) as signed strength
      - smooths by averaging last N margins, then outputs sign -> 0/1
    """

    def __init__(self, pack: dict):
        self.W = np.asarray(pack["W"], dtype=np.float32)
        self.picks = np.asarray(pack["picks"], dtype=int)
        self.clf = pack["clf"]  # sklearn estimator (SVM)

        self.baseline_samples = int(float(CSP_BASELINE_SECONDS) * float(SAMPLING_RATE))
        self.seen_samples = 0

        # store signed margins (positive => class 1)
        self.margin_hist = deque(maxlen=max(1, int(CSP_SMOOTH_VOTES)))

    def process(self, window_t64: np.ndarray, n_new: int):
        # IMPORTANT: count only NEW samples streamed in, not the full window length.
        self.seen_samples += int(n_new)
        if self.seen_samples < self.baseline_samples:
            return None

        w_tc = preprocess_window(window_t64)  # [T, Ccsp]
        if w_tc is None:
            return None

        feats = _logvar_feats(w_tc, self.W, self.picks)  # [1, k]

        # Signed strength: SVM margin. Positive => predicts class 1.
        # (Works for SVC / LinearSVC; falls back to predict if needed.)
        if hasattr(self.clf, "decision_function"):
            m = float(np.ravel(self.clf.decision_function(feats))[0])
        else:
            pred = int(self.clf.predict(feats)[0])
            m = 1.0 if pred == 1 else -1.0

        self.margin_hist.append(m)

        m_avg = float(np.mean(self.margin_hist))
        return 1 if m_avg > 0.0 else 0
